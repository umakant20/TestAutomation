using System.Text;
using PRImpactAnalyzer.Core.Models;

namespace PRImpactAnalyzer.Core.Pipeline;

/// <summary>
/// Builds the structured prompt sent to GitHub Copilot.
/// Separates prompt construction from LLM interaction so it can be tested independently.
/// </summary>
public class PromptBuilder
{
    public string Build(
        PrMetadata prMetadata,
        List<ChangedSymbol> symbols,
        List<ScenarioRecord> scenarios)
    {
        var sb = new StringBuilder();

        sb.AppendLine("You are a test impact analyzer for a .NET / ColdFusion / SOAP codebase tested with C# SpecFlow (Reqnroll).");
        sb.AppendLine("Your task: given a set of changed code symbols from a pull request, identify which test scenarios are likely impacted.");
        sb.AppendLine();
        sb.AppendLine("## Output format (STRICT — return ONLY this JSON, no markdown, no explanation)");
        sb.AppendLine("""
{
  "impacted": [
    {
      "scenarioName": "exact scenario name from the list below",
      "featureFile": "relative path to .feature file",
      "matchedChange": "which changed symbol triggered this match",
      "confidence": "HIGH | MEDIUM | VERIFY",
      "reason": "one sentence explanation"
    }
  ]
}
""");
        sb.AppendLine("Confidence rules:");
        sb.AppendLine("  HIGH   — a step definition directly references the changed method name, endpoint route, or SOAP operation.");
        sb.AppendLine("  MEDIUM — semantic match: the scenario covers the same business behaviour as the changed code.");
        sb.AppendLine("  VERIFY — plausible indirect impact; flag for human review.");
        sb.AppendLine("  Omit   — scenarios with no plausible connection to any changed symbol.");
        sb.AppendLine();

        // PR context
        sb.AppendLine("## Pull Request");
        sb.AppendLine($"Title      : {prMetadata.Title}");
        sb.AppendLine($"Description: {Truncate(prMetadata.Description, 500)}");
        sb.AppendLine($"Branch     : {prMetadata.SourceBranch} → {prMetadata.TargetBranch}");
        sb.AppendLine();

        // Changed symbols
        sb.AppendLine("## Changed symbols extracted from the PR diff");
        if (!symbols.Any())
        {
            sb.AppendLine("(no recognizable symbols extracted — rely on PR title/description for semantic matching)");
        }
        else
        {
            foreach (var g in symbols.GroupBy(s => s.File))
            {
                sb.AppendLine($"### {g.Key}");
                foreach (var sym in g)
                {
                    var label = sym.Change switch
                    {
                        ChangeType.RenameFrom     => $"RENAMED FROM → {sym.OldSymbol ?? sym.Symbol}",
                        ChangeType.RenameTo       => $"RENAMED TO   → {sym.Symbol}",
                        ChangeType.Removed        => $"REMOVED      {sym.Symbol}",
                        ChangeType.Added          => $"ADDED        {sym.Symbol}",
                        ChangeType.SignatureChanged=> $"SIG-CHANGE   {sym.Symbol}",
                        ChangeType.BodyChanged    => $"BODY-CHANGE  {sym.Symbol}",
                        _                         => $"STABLE       {sym.Symbol}"
                    };

                    sb.AppendLine($"  [{sym.Kind}] {label}" +
                                  (sym.AdditionalContext is { Length: > 0 } ctx ? $"  ({ctx})" : ""));
                }
            }
        }
        sb.AppendLine();

        // Scenario index
        sb.AppendLine("## Test scenarios to evaluate");
        foreach (var s in scenarios)
        {
            sb.AppendLine($"---");
            sb.AppendLine($"Scenario   : {s.ScenarioName}");
            sb.AppendLine($"Feature    : {s.FeatureFile}");
            if (s.Tags.Any())
                sb.AppendLine($"Tags       : {string.Join(", ", s.Tags)}");
            if (s.BoundEndpoints.Any())
                sb.AppendLine($"Endpoints  : {string.Join(", ", s.BoundEndpoints)}");
            if (s.BoundPageObjects.Any())
                sb.AppendLine($"PageObjects: {string.Join(", ", s.BoundPageObjects)}");
            if (s.BoundSoapProxies.Any())
                sb.AppendLine($"SoapProxies: {string.Join(", ", s.BoundSoapProxies)}");
            sb.AppendLine($"Steps      : {string.Join(" | ", s.Steps.Take(6))}");
        }

        return sb.ToString();
    }

    private static string Truncate(string text, int max) =>
        text.Length <= max ? text : text[..max] + "…";
}
