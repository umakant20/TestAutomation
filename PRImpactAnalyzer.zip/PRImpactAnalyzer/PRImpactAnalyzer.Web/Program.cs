using PRImpactAnalyzer.Core.Interfaces;
using PRImpactAnalyzer.Core.Pipeline;
using PRImpactAnalyzer.Infrastructure.Git;
using PRImpactAnalyzer.Infrastructure.Http;
using PRImpactAnalyzer.Plugins.ColdFusion;
using PRImpactAnalyzer.Plugins.DotNet;
using PRImpactAnalyzer.Plugins.Soap;
using PRImpactAnalyzer.Plugins.SpecFlow;

var builder = WebApplication.CreateBuilder(args);

// ── Blazor Server ────────────────────────────────────────────────────────────
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

// ── Configuration ────────────────────────────────────────────────────────────
var cfg = builder.Configuration.GetSection("PrImpactAnalyzer");

// ── Infrastructure ───────────────────────────────────────────────────────────
builder.Services.AddSingleton<IPrDiffProvider, AzureDevOpsPrDiffProvider>();

// ILlmOrchestrator is registered as a factory so it picks up the API key
// from the AnalysisRequest at call time (key can be changed per-run in the UI)
builder.Services.AddTransient<ILlmOrchestrator>(sp =>
    new GitHubCopilotOrchestrator(
        apiKey:   cfg["CopilotApiKey"] ?? string.Empty,
        endpoint: cfg["CopilotApiEndpoint"] ?? "https://api.githubcopilot.com/chat/completions",
        model:    cfg["CopilotModel"] ?? "gpt-4o",
        logger:   sp.GetRequiredService<ILogger<GitHubCopilotOrchestrator>>()));

// ── Plugins ──────────────────────────────────────────────────────────────────
// Code analyzers — order matters: more specific first
builder.Services.AddSingleton<ICodeAnalyzer, SoapWsdlAnalyzer>();
builder.Services.AddSingleton<ICodeAnalyzer, DotNetAnalyzer>();
builder.Services.AddSingleton<ICodeAnalyzer, ColdFusionAnalyzer>();

// Test parsers
builder.Services.AddSingleton<ITestParser, SpecFlowParser>();  // handles both SpecFlow and Reqnroll

// ── Pipeline ─────────────────────────────────────────────────────────────────
builder.Services.AddSingleton<PromptBuilder>();
builder.Services.AddSingleton<LlmResponseParser>();
builder.Services.AddTransient<AnalysisPipeline>();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseAntiforgery();

app.MapRazorComponents<PRImpactAnalyzer.Web.Components.App>()
   .AddInteractiveServerRenderMode();

app.Run();
